Saved final state of a static bending benchmark, not a robot cell.
Red OfflineReference curves are human review guides, not policy inputs.
Open bending.usda in Isaac with the timeline paused.
See settings.json for the numerical profile; material values are assumptions.
