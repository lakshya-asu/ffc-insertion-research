# Frozen sources: socket-centered-002

Build with `docker build -t ffc-insertion-rerun:6.1.0 .`, then `bash run.sh rerun-001`.
On the original lab machine, use `FFC_RUNTIME_IMAGE=ffc-isaac:6.1.0 bash run.sh rerun-001`.
NVIDIA GPU Docker support and Isaac licence acceptance are required.

This bundle has not had a fresh image build or an independent physics rerun.
It includes recorded source snapshots and the current CAD asset, hashed at packaging.
The experiment did not hash that CAD at acquisition, so its historic identity is not independently proved.
USD playback is separate from physics execution. Supplier ownership is unchanged.
Check report.json and sensor-trace.json, not only process exit status. No seating is verified.
