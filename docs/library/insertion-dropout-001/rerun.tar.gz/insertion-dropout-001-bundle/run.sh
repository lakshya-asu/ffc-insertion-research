#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
run_name="${1:-rerun-001}"
[[ "$run_name" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 2
test ! -e "outputs/$run_name"
docker run --rm --gpus all --shm-size=4gb -e ACCEPT_EULA=Y -e OMNI_KIT_ACCEPT_EULA=YES -e PRIVACY_CONSENT=N -v "$PWD:/workspace" -w /workspace "${FFC_RUNTIME_IMAGE:-ffc-insertion-rerun:6.1.0}" scripts/isaac_insertion_bench.py --case load_dropout --dt 0.000125 --segments 100 --output "/workspace/outputs/$run_name"
