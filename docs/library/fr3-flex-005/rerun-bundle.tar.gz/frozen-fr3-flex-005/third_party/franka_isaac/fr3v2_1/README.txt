Isaac Sim USD package: fr3v2_1
Isaac Sim version: 6.0.0-rc.59
Main file: fr3v2_1.usda

Open fr3v2_1.usda in Isaac Sim 6.0.0-rc.59.
All layer/payload references are relative under this directory.
