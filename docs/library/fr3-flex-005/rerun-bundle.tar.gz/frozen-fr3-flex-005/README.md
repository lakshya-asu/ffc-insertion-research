# Frozen rerun bundle: fr3-flex-005

Source snapshots and CAD/robot assets are included. Requires NVIDIA Docker GPU support and acceptance of the Isaac Sim licence. No credentials or camera streams are included.

```bash
docker build -t ffc-mounted-rerun:6.1.0 .
bash run.sh rerun-001
```

On the original lab machine, reuse its recorded runtime:

```bash
FFC_RUNTIME_IMAGE=ffc-isaac:6.1.0 bash run.sh rerun-001
```

A recorded failure should remain a failure. Inspect report.json, failure.txt and sensor-trace.json; container exit status alone is insufficient. Reruns start fresh physics; USD timeline playback is separate. Build recipe pins the Isaac base and Python packages but OS packages/driver are not fully hermetic. Bitwise equality across drivers and GPUs is not established. Source/CAD supplier ownership is unchanged.
